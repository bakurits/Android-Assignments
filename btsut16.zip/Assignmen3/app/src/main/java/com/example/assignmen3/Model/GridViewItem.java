package com.example.assignmen3.Model;

public class GridViewItem {
    public String name;
}
