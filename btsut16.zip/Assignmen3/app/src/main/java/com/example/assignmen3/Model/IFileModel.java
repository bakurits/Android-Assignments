package com.example.assignmen3.Model;

public interface IFileModel {

    public int getIconID();
    public int itemCnt();
}
