package com.example.assignmen3.Model;


import java.util.List;

public class GridViewModel {
    public String path;
    List<IFileModel> files;
}
